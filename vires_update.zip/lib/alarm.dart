import 'package:flutter/services.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:vibration/vibration.dart';

/// Rings the phone and vibrates when the rest timer ends.
/// On a computer (like your Linux test window) these plugins do nothing, and that is fine.
Future<void> ringAndVibrate() async {
  try {
    await Vibration.vibrate(pattern: [0, 400, 200, 400, 200, 600]);
  } catch (_) {
    HapticFeedback.vibrate();
  }
  try {
    await FlutterRingtonePlayer().play(
      android: AndroidSounds.alarm,
      ios: IosSounds.alarm,
      looping: false,
      volume: 1.0,
      asAlarm: true, // rings even if the phone is on silent
    );
    Future.delayed(const Duration(seconds: 4), stopRing); // never let it ring for long
  } catch (_) {}
}

Future<void> stopRing() async {
  try {
    await FlutterRingtonePlayer().stop();
  } catch (_) {}
}
